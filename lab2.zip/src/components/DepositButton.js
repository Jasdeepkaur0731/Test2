import React from 'react';

function DepositButton({ onClick }) {
  return <button onClick={onClick}>Deposit</button>;
}

export default DepositButton;